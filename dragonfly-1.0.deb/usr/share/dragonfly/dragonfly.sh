#!/bin/bash

clear

USERNAME=$(whoami)
WHEREAMI=$(pwd)

clear

echo "===================================================================================="
echo "                    DragonFly v1.0 | System Cleaning Utility                        "
echo "===================================================================================="

read -p "DragonFly will be cleaning your system, this involves Emptying Your Trash, Clearing Simple File Backups (*~), Running apt-get commands, and Clearing some Network Cache files.. Shall we proceed? (y/n): " DACT
dact="$DACT"

clear

if [ $dact = "y" ]
then
	clear
	sudo apt-get autoremove
	clear
	sudo apt-get autoclean
	clear
	sudo apt-get update
	clear
	sudo rm -r /home/$USERNAME/*~
	sudo rm -r /home/$USERNAME/Desktop/*~
	sudo rm -r /home/$USERNAME/Documents/*~
	sudo rm -r /home/$USERNAME/Downloads/*~
	rm -r /home/$USERNAME/.local/share/Trash/files
	mkdir /home/$USERNAME/.local/share/Trash/files
	clear
	notify-send --urgency="critical" --icon="/usr/share/dragonfly/dragonfly.svg" "DragonFly.." "Your System is now Clean!"
	sleep 3
	clear

elif [ $dact = "Y" ]
then
	clear
	sudo apt-get autoremove
	clear
	sudo apt-get autoclean
	clear
	sudo apt-get update
	clear
	sudo rm -r /home/$USERNAME/*~
	sudo rm -r /home/$USERNAME/Desktop/*~
	sudo rm -r /home/$USERNAME/Documents/*~
	sudo rm -r /home/$USERNAME/Downloads/*~
	rm -r /home/$USERNAME/.local/share/Trash/files
	mkdir /home/$USERNAME/.local/share/Trash/files
	clear
	notify-send --urgency="critical" --icon="/usr/share/dragonfly/dragonfly.svg" "DragonFly.." "Your System is now Clean!"
	sleep 3
	clear

elif [ $dact = "n" ]
then
	clear
	echo "Exiting DragonFly.."
	sleep 3
	clear

elif [ $dact = "N" ]
then
	clear
	echo "Exiting DragonFly.."
	sleep 3
	clear
else
	clear
	echo "Unknown Reply, Exiting DragonFly.."
	sleep 3
	clear
fi

clear
